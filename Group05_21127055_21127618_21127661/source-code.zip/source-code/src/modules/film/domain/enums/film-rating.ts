export enum FilmRating {
  PG = 'PG',
  G = 'G',
  NC_17 = 'NC-17',
  PG_13 = 'PG-13',
  R = 'R',
}
